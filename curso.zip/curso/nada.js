for(let i=0; i < 5000; i++){
    console.log(i,i,i,i);
}
