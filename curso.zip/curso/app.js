//importe o module express
const express = require('express');

//importando o modulo express-fileupload
const fileupload = require('express-fileupload')

//importando o handlebars
const { engine } = require('express-handlebars');

// importando modulo mysql
const mysql = require('mysql2');

//file system
const fs = require('fs');

//app
const app = express();

//habilitando o upload de arquivos
app.use(fileupload());

//adicionando o bootstrap
app.use('/bootstrap', express.static('./node_modules/bootstrap/dist'));

//adicionando css
app.use('/css', express.static('./css'));


//referenciar pasta de imagem
app.use('/imagens', express.static('./imagens'));

//configurando conexao
const conexao = mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'antonio',
    database:'projectos'
});

//configurando o handlebars
app.engine('handlebars', engine());
app.set('view engine', 'handlebars');
app.set('views', './views');

//manipulacao de dados via rota
app.use(express.json());
app.use(express.urlencoded({extended:false}));

//teste de conexao
conexao.connect(function(erro){
    if(erro) throw erro;
    console.log('conexão feita com sucesso');
});

//rota principal
app.get('/', function(req, res){
    //sql
    let sql = "SELECT * FROM produtos";

    //executar comando sql
    conexao.query(sql, function(erro, retorno){
        res.render('formulario', {produtos:retorno});
    });
});


//rota principal contendo a situacao
app.get('/:situacao', function(req, res){
    //sql
    let sql = "SELECT * FROM produtos";

    //executar comando sql
    conexao.query(sql, function(erro, retorno){
        res.render('formulario', {produtos:retorno, situacao:req.params.situacao});
    });
});

//rota de cadastro
app.post('/cadastrar', function(req, res){
try{
//obter rotas de dados para o cadastro
let nome = req.body.nome;
let valor = req.body.valor;
let imagem = req.files.imagem.name;

//validar o nome do produto e o valor
if(nome == '' || valor == '' || isNaN(valor)){
    res.redirect('/falhaCadastro');
}else{
//SQL
let sql = `INSERT INTO produtos (nome, valor, imagem) VALUES ('${nome}', ${valor}, '${imagem}')`;

//executar comando sql
conexao.query(sql, function(erro, retorno){

    //caso ocorra erros
    if(erro) throw erro;

    //caso ocorra o cadstro
    req.files.imagem.mv(__dirname+'/imagens/'+req.files.imagem.name);
    console.log(retorno);
});

//retornar a rota principal
res.redirect('/okCadastro');
}


}catch(erro){
    res.redirect('/falhaCadastro')
}
});


//rota para remover produtos
app.get('/remover/:codigo&:imagem', function(req, res){
    //usamos os comandos abaixos quando não estivermos a usar o MYSQL
    //console.log(req.params.codigo) ;
   // console.log(req.params.imagem);
    //res.end();
  
    //SQL
    let sql = `DELETE FROM produtos WHERE codigo = ${req.params.codigo}`;

    //executar o comando sql
    conexao.query(sql, function(erro, retorno){
        //caso falhe o comando sql
        if(erro) throw erro;
        //caso o comando sql funcione
        fs.unlink(__dirname+"/imagens/"+req.params.imagem, (erro_imagem)=>{
            console.log("falha ao remover a imagem");
        });
    });

    //redirecionamento
    res.redirect('/');
});

//rota para redirecionar para o formulario de alteracao/edicao
app.get('/formularioEditar/:codigo', function(req, res){
   //SQL
   let sql = `SELECT * FROM produtos  WHERE codigo = ${req.params.codigo}`;
   //Executar o comando sql
   conexao.query(sql, function(erro, retorno){
//caso haja erro no comando sql
if(erro) throw erro;

//caso consiga executar o comando sql
res.render('formularioEditar', {produto:retorno[0]});
   });
});

//Rota para editar produtos
app.post('/editar', function(req, res){

    //obter os dados do formulario
    let nome = req.body.nome;
    let valor = req.body.valor;
    let codigo = req.body.codigo;
    let nomeImagem = req.body.nomeImagem;
   
    //validar nome do produto e valor
    if(nome == '' || valor == '' || isNaN(valor)){
        res.redirect('/falhaEdicao');
    }else{

        //Definir o tipo de edicao
    try{

    //objecto de imagem
    let imagem = req.files.imagem;

    //SQL
    let sql = `UPDATE produtos SET nome='${nome}', valor=${valor}, imagem='${imagem.name}' WHERE codigo=${codigo}`;

    //Executar comando SQL
    conexao.query(sql, function(erro, retorno){

        //caso falhe o comando SQL
        if(erro) throw erro;

        //Remover imagem antiga
        fs.unlink(__dirname+'/imagens/'+nomeImagem, (erro_imagem)=>{
            console.log('Falha ao remover a imagem.');
    });

    //Cadastrar nova imagem
    imagem.mv(__dirname+'/imagens/'+imagem.name);
    });
    }catch(erro){
    //SQL
    let sql = `UPDATE produtos SET nome='${nome}', valor=${valor}WHERE codigo=${codigo}`;
    //Executar comando sql
    conexao.query(sql, function(erro, retorno){
        //caso falhe o comando sql
        if(erro) throw erro;
    });
    }

        //Redirecionamento
        res.redirect('/okEdicao');
}
});
//servidor
app.listen(8080)
console.log("Servidor rodando na localhost:8080");

